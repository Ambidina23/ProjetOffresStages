package Controller;

import javafx.event.ActionEvent;

import javafx.fxml.FXML;
import javafx.scene.control.Button;

public class EditerOffresControl {

    @FXML
    private Button SupprimerOffre;

    @FXML
    private Button Rechercher;

    @FXML
    void AddRechercher(ActionEvent event) {

    }

    @FXML
    void AddSupprimerOffre(ActionEvent event) {

    }

}

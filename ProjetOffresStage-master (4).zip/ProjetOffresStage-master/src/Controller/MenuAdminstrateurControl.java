package Controller;

import java.io.IOException;


import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.stage.Stage;

public class MenuAdminstrateurControl {


    @FXML
    private Button EditerOffre;

    @FXML
    private Button EditerEtudiant;

    @FXML
    private Button EditerEntreprise;

    @FXML
    void AddEditerEntreprise(ActionEvent event) {
    	Stage primaryStage= new Stage();
    	
    	primaryStage.setTitle("Edit Entreprise" );
		Parent root;
		try {
			root = FXMLLoader.load(getClass().getResource("/View/EditerEntreprises.fxml"));
			Scene scene= new Scene(root);
			primaryStage.setScene(scene);
			primaryStage.show();
			primaryStage.setResizable(false);
			
			
		} catch (IOException e1) {
			e1.printStackTrace();
		}

    }

    @FXML
    void AddEditerEtudiant(ActionEvent event) {
    	    	Stage primaryStage= new Stage();
    	    	
    	    	primaryStage.setTitle("Edit Etudiant" );
    			Parent root;
    			try {
    				root = FXMLLoader.load(getClass().getResource("/View/EditerEtudiants.fxml"));
    				Scene scene= new Scene(root);
    				primaryStage.setScene(scene);
    				primaryStage.show();
    				primaryStage.setResizable(false);
    			
    			} catch (IOException e1) {
    				e1.printStackTrace();
    			}
    			
    }

    @FXML
    void AddEditerOffre(ActionEvent event) {
    	Stage primaryStage= new Stage();
    	
    	primaryStage.setTitle("Edit Offre" );
		Parent root;
		try {
			root = FXMLLoader.load(getClass().getResource("/View/EditerOffres.fxml"));
			Scene scene= new Scene(root);
			primaryStage.setScene(scene);
			primaryStage.show();
			primaryStage.setResizable(false);
			
		} catch (IOException e1) {
			e1.printStackTrace();
		}
    }

}

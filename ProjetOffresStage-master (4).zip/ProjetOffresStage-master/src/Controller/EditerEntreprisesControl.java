package Controller;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;

public class EditerEntreprisesControl {

    @FXML
    private Button RechercherEntreprise;

    @FXML
    private Button SuprimerEntreprise;

    @FXML
    void AddRechercherEntrperise(ActionEvent event) {

    }

    @FXML
    void AddSuprimerEntreprise(ActionEvent event) {

    }

}

package Controller;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;

public class EditerEtudiantsControl {

    @FXML
    private Button Rechercher;

    @FXML
    private Button SuprimerEtudiant;

    @FXML
    void AddRechercher(ActionEvent event) {

    }

    @FXML
    void AddSuprimerEtudiant(ActionEvent event) {

    }

}
